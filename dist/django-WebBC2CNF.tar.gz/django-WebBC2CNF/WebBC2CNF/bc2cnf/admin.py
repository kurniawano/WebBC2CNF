from django.contrib import admin
from .models import Submission

# Register your models here.
admin.site.register(Submission)
